FixWANotifications16 v1.0.1

Based on FixWANotifs by 0xkuj.

Changes in this build:
- Renamed the tweak and Settings entry to FixWANotifications16.
- New package ID: com.0xkuj.fixwanotifications16.
- Jetsam choices are exactly 40 / 72 / 96 / 112 / 128 MiB.
- 160 / 192 / 256 MiB options were removed.
- 112 MiB is explicitly accepted by the runningboardd hook.
- The preference domain is com.0xkuj.fixwanotifications16prefs.
- Uses PSListItemsController so the Memory Limit selector is populated.
- Standard Dopamine rootless layout and clean uninstall scripts are included.
- Conflicts/Replaces the original com.0xkuj.fixwanotifs package so both hooks cannot be installed at once.

A userspace reboot is required after changing the Jetsam limit and after removal.


v1.0.1 metadata update
- Author: 551 & 0xkuj
- Maintainer: 551 & 0xkuj
- Expanded Sileo package description with observed memory guidance.


FixWANotifications16 v1.0.2
- Added actual selectable Jetsam targets: 150 MiB, 180 MiB and 256 MiB.
- Existing targets retained: 40, 72, 96, 112 and 128 MiB.
- The same JetsamLimit preference is read by the runningboardd hook.
- When runningboardd attempts to set WhatsApp ServiceExtension's 24 MiB limit, the hook rewrites the active/inactive value to the selected target.
- Added an os_log diagnostic message only when the WhatsApp ServiceExtension limit is actually rewritten.
- Userspace reboot remains recommended after changing the preference.
